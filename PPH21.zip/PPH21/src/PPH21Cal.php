<?php

namespace oop\PPH21\src;

final class PPH21Cal{
    private $calculator;
    public function __construct(CalInterface ...$calculator){
        $this->calculator = $calculator;
    }
    public function calculate(float $pkp): float{
        foreach ($this->calculator as $calculators){
            if ($pkp < $calculators->maxPkp() && $pkp >= $calculators->minPkp()){
                return $calculators->calculate($pkp);
            }
        }
    }
}