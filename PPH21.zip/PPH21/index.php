<?php

require __DIR__.'/vendor/autoload.php';

use oop\PPH21\src\FirstRuleCal;
use oop\PPH21\src\SeccRuleCal;
use oop\PPH21\src\ThirdRuleCal;
use oop\PPH21\src\FourthRuleCal;
use oop\PPH21\src\PPH21Cal;

$first = new FirstRuleCal();
$secc = new SeccRuleCal($first);
$third = new ThirdRuleCal($secc);
$fourth = new FourthRuleCal($third);

$calculators = new PPH21Cal ($first, $secc, $third, $fourth);

//1.250.000
echo $calculators->calculate(25000000) . "\n";
echo "<br>";
//1.500.000
echo $calculators->calculate(30000000) . "\n";
echo "<br>";
//2.250.000
echo $calculators->calculate(45000000) . "\n";
echo "<br>";
//2.500.000
echo $calculators->calculate(50000000) . "\n";
echo "<br>";
//4.000.000
echo $calculators->calculate(60000000) . "\n";
echo "<br>";
//6.250.000
echo $calculators->calculate(75000000) . "\n";
echo "<br>";
//32.5000.000
echo $calculators->calculate(250000000) . "\n";
echo "<br>";
//45.000.000
echo $calculators->calculate(300000000) . "\n";
echo "<br>";
//82.500.000
echo $calculators->calculate(450000000) . "\n";
echo "<br>";
//170.000.000
echo $calculators->calculate(750000000) . "\n";
echo "<br>";